using System;
using System.Net;
namespace InfoTrackMain1.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);

        public string Client { get; set; }

        public string HttpClient { get; set; }

    }
}

