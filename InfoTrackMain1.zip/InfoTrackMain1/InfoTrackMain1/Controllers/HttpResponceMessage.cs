﻿using System;

namespace InfoTrackMain1.Controllers
{
    internal class HttpResponceMessage
    {
        internal object content;

        internal void EnsureSuccessStatusCode()
        {
            throw new NotImplementedException();
        }
    }
}