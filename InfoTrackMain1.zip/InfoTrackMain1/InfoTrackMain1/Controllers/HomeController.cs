﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using InfoTrackMain1.Models;
using System.Net.Http;


namespace InfoTrackMain1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        //public class LandRegistrySearches : System.Net.HttpListenerTimeoutManager
        //{
        static readonly HttpClient client = new HttpClient();

        public static object Client { get; private set; }

        private static async Task Main()
        {
            try
            {
                HttpResponceMessage responce = await Client.Getasync("https://www.google.co.uk/search?num=100&q=land+registry+search");
                responce.EnsureSuccessStatusCode();
                string responceBody = await responce.content.ReadAsStringAsync();

                Console.WriteLine(responce);
            }
            catch (HttpRequestException)
            {
                Console.WriteLine();
                Console.WriteLine();
            }
        }

        private Task<HttpResponceMessage> GetAsync(string v)
        {
            throw new NotImplementedException();
        }

    }
    }

